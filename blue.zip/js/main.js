var adapter = tizen.bluetooth.getDefaultAdapter();
//var serviceUUID = "A49EB41E-CB06-495C-9F4F-BB80A90CDF00";
var serviceUUID = "00001101-0000-1000-8000-00805F9B3520";
// Holds currently registered service record	
var chatServiceHandler = null;
// Holds currently open socket
var serviceSocket = null;

function basicVibration()
{
   // Vibrate for 1.5 seconds 
   navigator.vibrate(1500);
}

function patternVibration1()
{
   // Vibrate in a give pattern : 1 sec on, 0.5 sec off, 2 sec on
	navigator.vibrate([1000, 300, 1000]);
} 

function patternVibration2()
{
	navigator.vibrate([500, 300, 500,300,500]);
} 


function BluetoothServiceSuccessCallback(recordHandler) {
	
	Screen sleeptimeout = SleepTimeOut.NeverSleep;
	
	console.log("Chat service registration succeeds!");
    chatServiceHandler = recordHandler;
    recordHandler.onconnect = function(socket) {
    	window.console.log("Client connected: " + socket.peer.name + "," + socket.peer.address);
        serviceSocket = socket;
        // Messages received from remote device
        socket.onmessage = function() {
             var data = socket.readData();
             var recvmsg = "";
             console.log("length >> " + data.length);
             for (var i = 0; i < data.length; i++)
             {
                recvmsg += String.fromCharCode(data[i]);
                console.log("length >> " + data[i]);
             }
             //recvmsg += data[0];
             console.log("server msg >> " + recvmsg);
            
             var t1 = "";
             t1 += String.fromCharCode(39);
             t1 += String.fromCharCode(49);
             t1 += String.fromCharCode(39);
             
             var t2 = "";
             t2 += String.fromCharCode(39);
             t2 += String.fromCharCode(50);
             t2 += String.fromCharCode(39);
             
             var t3 = "";
             t3 += String.fromCharCode(39);
             t3 += String.fromCharCode(51);
             t3 += String.fromCharCode(39);
             
             console.log("t1 >> " + t1);
             console.log("t2 >> " + t2);
             console.log("t3 >> " + t3);
             
             if(recvmsg == t1){
            	 basicVibration();
             }
             else if(recvmsg == t2){
            	 patternVibration1();
             }
             else {
            	 patternVibration2();
             }
             
             
             

        };

        socket.onclose = function() {
        	window.console.log('The socket is closed.');
            serviceSocket = null;
        };
    };
 };
 
 function RFCOMMServiceE(e){
	 window.console.log( "Could not register service record, Error: " + e.message);
 }
 

window.onload = function() {
    document.addEventListener('tizenhwkey', function(e) {
        if (e.keyName === "back") {
            try {
                tizen.application.getCurrentApplication().exit();
            } catch (ignore) {}
        }
    });
    
    adapter.registerRFCOMMServiceByUUID(serviceUUID, "My RFCOMM service",BluetoothServiceSuccessCallback,RFCOMMServiceE);
 
    console.log("right?");

};
